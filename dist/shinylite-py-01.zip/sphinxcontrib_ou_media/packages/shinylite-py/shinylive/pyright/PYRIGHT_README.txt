Pyright as a Web Worker.

Source: https://github.com/microbit-foundation/pyright
